---
layout: home
title: Home
---

# Welcome to Global Business Insight

This site is powered by **Jekyll** and hosted on **GitHub Pages**.

Feel free to add your content here.
