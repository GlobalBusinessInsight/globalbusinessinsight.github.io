# Global Business Insight

This repository hosts the official website built with [Jekyll](https://jekyllrb.com) and deployed via [GitHub Pages](https://pages.github.com).

## 📦 Quick Setup

1. Edit `index.md` to customize your homepage
2. Modify `_config.yml` to set site title and options
3. Push to `main` branch – GitHub will build it automatically

## 🧪 Theme

Using [minima](https://github.com/jekyll/minima) – a supported GitHub Pages theme.
